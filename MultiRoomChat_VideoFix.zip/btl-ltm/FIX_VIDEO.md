# Sửa lỗi gửi video / file lớn

## Lỗi cũ
- `app.js` từ chối định dạng `.mp4`, `.webm`, `.mov` và file >600 KB.
- File truyền qua dòng `FILE ... BASE64` trong WebSocket -> TCP.
- Bộ nhận WebSocket cũ đẩy các frame `continuation` riêng lẻ thành lệnh mới, gây lỗi `Lệnh không hợp lệ: XWPK4...` khi dữ liệu bị chia frame.

## Đã sửa
- Upload từ Web qua HTTP POST `/api/upload` bằng dữ liệu nhị phân (raw file bytes), không Base64.
- Tên file, phòng/PM và session token truyền qua header; Server xác thực session và quyền gửi file.
- Server nhận tệp theo luồng, giới hạn 50 MiB mỗi tệp, lưu `uploads/<uuid>` và metadata trong SQLite.
- Hỗ trợ `.mp4`, `.webm`, `.mov` bên cạnh ảnh/PDF/TXT/ZIP.
- Video có nút `Xem video` (nếu codec trình duyệt hỗ trợ) và `Tải về`.
- Bộ nhận WebSocket đã ghép các frame continuation thành một message trước khi chuyển qua TCP.
- Truyền file qua lệnh FILE trên TCP Client cũ vẫn giới hạn 600 KB.

## Cập nhật trên NetBeans
1. Dừng hẳn phiên Server cũ đang dùng cổng 8080/5000.
2. Giải nén ZIP mới vào một thư mục riêng; mở thư mục `btl-ltm` trong NetBeans.
3. Clean and Build; Run Project (F6).
4. Mở http://localhost:8080 rồi Ctrl+Shift+R để xóa phiên JavaScript cũ trong cache.
5. Đăng nhập, vào `lobby` hoặc chat riêng, chọn nút kẹp giấy, chọn video MP4 ngắn dưới 50 MiB.
6. Sau upload thành công, tệp xuất hiện trong đoạn chat; thử tải về và xem trước.

## Kiểm thử dự kiến
- Gửi MP4 <50 MiB, nhận FILEMSG và tải về đúng nội dung.
- Gửi MP4 >50 MiB, nhận lỗi rõ ràng, không upload.
- Gửi video trong PM, người không thuộc PM không tải được (HTTP 403).
- Gửi PNG/JPG, PDF và ZIP như trước.
- Nếu video không phát được trong Chrome do codec MOV, tải về bằng liên kết file.

## Kết quả đã kiểm tra trong môi trường tạo bản sửa
- `javac --release 11` biên dịch toàn bộ mã Java: đạt.
- `node --check app.js`: đạt.
- Bài kiểm thử mô phỏng WebSocket chia thành hai frame, tổng 300004 ký tự: ghép và chuyển đúng thành một lệnh.
- Chưa kiểm thử full luồng HTTP + SQLite trên NetBeans của người dùng; cần chạy để xác nhận đường upload thực tế.
