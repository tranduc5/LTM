package chatapp.web;

import chatapp.server.Server;
import chatapp.logic.ChatDatabase;
import chatapp.logic.Sessions;
import java.nio.file.Files;
import java.nio.file.Path;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * Cổng web (chủ sở hữu: TV1): phục vụ trang web (HTTP) và cầu nối WebSocket -> chat server TCP.
 * Mỗi kết nối WebSocket mở một kết nối TCP riêng tới chat server, nên trình duyệt
 * hoạt động như một client bình thường (chat chung được với GuiClient/CliClient).
 *
 * Chạy: java WebServer [webPort] [chatPort]   (mặc định 8080 và 5000)
 * Server chat TCP được khởi động cùng trong tiến trình này.
 */
public class WebServer {
    private static final String WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    public static void main(String[] args) throws Exception {
        int webPort = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        int chatPort = args.length > 1 ? Integer.parseInt(args[1]) : Server.DEFAULT_PORT;

        // Khởi tạo SQLite/logic trước khi mở HTTP: tránh hiện trang đăng nhập
        // trong khi TCP Server đã chết do không mở được database.
        Server backend = new Server(chatPort);
        Thread chat = new Thread(() -> {
            try {
                backend.start();
            } catch (Exception e) {
                Server.log("Không khởi động được TCP chat server cổng " + chatPort + ": " + e);
                e.printStackTrace();
                System.exit(1);
            }
        }, "chat-server");
        chat.setDaemon(true);
        chat.start();
        Thread.sleep(300);

        try (ServerSocket ss = new ServerSocket(webPort)) {
            Server.log("Mở trình duyệt tại http://localhost:" + webPort);
            while (true) {
                Socket s = ss.accept();
                new Thread(() -> handle(s, chatPort, backend)).start();
            }
        }
    }

    // ---------- HTTP ----------

    private static void handle(Socket s, int chatPort, Server backend) {
        try {
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();
            String head = readHead(in);
            if (head == null) return;
            String[] lines = head.split("\r\n");
            String[] req = lines[0].split(" ");
            Map<String, String> h = new HashMap<>();
            for (int i = 1; i < lines.length; i++) {
                int c = lines[i].indexOf(':');
                if (c > 0) h.put(lines[i].substring(0, c).trim().toLowerCase(), lines[i].substring(c + 1).trim());
            }
            String key = h.get("sec-websocket-key");
            if ("websocket".equalsIgnoreCase(h.get("upgrade")) && key != null) {
                websocket(s, in, out, key, chatPort);
            } else {
                String path=req.length>1?req[1]:"/";
                if("POST".equalsIgnoreCase(req[0]) && "/api/upload".equals(path))
                    upload(s,in,out,h,backend);
                else if("GET".equalsIgnoreCase(req[0]) && path.matches("/files/[a-f0-9-]{36}"))
                    serveFile(out,path,h.get("authorization"));
                else if("GET".equalsIgnoreCase(req[0])) serveStatic(out,path);
                else httpError(out,"405 Method Not Allowed");
            }
        } catch (IOException ignored) {
        } finally {
            try { s.close(); } catch (IOException ignored) { }
        }
    }

    /** Stream the request body to disk; never send Base64 file data through text commands. */
    private static void upload(Socket socket, InputStream in, OutputStream out,
                               Map<String,String> headers, Server backend) throws IOException {
        String auth=headers.getOrDefault("authorization","");
        String token=auth.startsWith("Bearer ")?auth.substring(7):"";
        if(Sessions.user(token)==null){httpError(out,"401 Unauthorized");return;}
        String encodedName=headers.get("x-file-name");
        String encodedTarget=headers.get("x-chat-target");
        String mode=headers.getOrDefault("x-chat-mode","");
        if(encodedName==null||encodedTarget==null){httpError(out,"400 Bad Request");return;}
        long size;
        try {size=Long.parseLong(headers.getOrDefault("content-length",""));}
        catch(NumberFormatException ex){httpError(out,"411 Length Required");return;}
        if(size<1){httpError(out,"400 Empty File");return;}
        if(size>50L*1024*1024){httpError(out,"413 File Too Large (max 50 MB)");return;}
        String name,target;
        try {
            name=java.net.URLDecoder.decode(encodedName,StandardCharsets.UTF_8);
            target=java.net.URLDecoder.decode(encodedTarget,StandardCharsets.UTF_8);
        } catch(IllegalArgumentException ex){httpError(out,"400 Bad Encoding");return;}
        if(name.length()>120||target.length()>100){httpError(out,"400 Invalid Metadata");return;}
        Path directory=Path.of("uploads");Files.createDirectories(directory);
        Path temp=Files.createTempFile(directory,".web-",".tmp");
        try {
            socket.setSoTimeout(60000);
            try(OutputStream file=Files.newOutputStream(temp)) {
                byte[] buf=new byte[65536];long remaining=size;
                while(remaining>0){
                    int read=in.read(buf,0,(int)Math.min(buf.length,remaining));
                    if(read<0)throw new EOFException("File upload incomplete");
                    file.write(buf,0,read);remaining-=read;
                }
            }
            String error=backend.uploadFile(token,mode,target,name,temp,size);
            if(error!=null) {httpText(out,"400 Bad Request",error);return;}
            httpText(out,"200 OK","Đã gửi file thành công");
        } finally {Files.deleteIfExists(temp);}
    }

    private static void httpText(OutputStream out,String status,String message)throws IOException {
        byte[] body=message.getBytes(StandardCharsets.UTF_8);
        out.write(("HTTP/1.1 "+status+"\r\nContent-Type: text/plain; charset=utf-8\r\n"
          +"Cache-Control: no-store\r\nContent-Length: "+body.length
          +"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(body);out.flush();
    }

    private static void serveFile(OutputStream out,String path,String authorization) throws IOException {
        String token=authorization!=null&&authorization.startsWith("Bearer ")?authorization.substring(7):"";
        String user=Sessions.user(token);
        if(user==null){httpError(out,"401 Unauthorized");return;}
        String[] f=new ChatDatabase().attachment(path.substring(7),user);
        if(f==null){httpError(out,"403 Forbidden");return;}
        Path file=Path.of("uploads",f[0]);
        if(!Files.isRegularFile(file)){httpError(out,"404 Not Found");return;}
        long length=Files.size(file);
        String type=f[1];
        String name=java.net.URLEncoder.encode(f[2],StandardCharsets.UTF_8).replace("+","%20");
        String disposition=(type.startsWith("image/")||type.startsWith("video/"))?"inline":"attachment";
        out.write(("HTTP/1.1 200 OK\r\nContent-Type: "+type+"\r\nX-Content-Type-Options: nosniff\r\nCache-Control: no-store\r\nContent-Disposition: "+disposition+"; filename*=UTF-8''"+name+"\r\nContent-Length: "+length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        Files.copy(file,out);out.flush();
    }
    private static void httpError(OutputStream out,String status)throws IOException{
        byte[] b=status.getBytes(StandardCharsets.UTF_8);
        out.write(("HTTP/1.1 "+status+"\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: "+b.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(b);out.flush();
    }

    private static String readHead(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            sb.append((char) c);
            if (sb.length() >= 4 && sb.substring(sb.length() - 4).equals("\r\n\r\n")) return sb.toString();
            if (sb.length() > 16384) return null;
        }
        return null;
    }

    private static void serveStatic(OutputStream out, String path) throws IOException {
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        if (path.equals("/")) path = "/index.html";
        byte[] body = null;
        String type = "text/plain; charset=utf-8";
        // Chỉ phục vụ file .html/.css/.js nằm trực tiếp trong resources/web (không cho phép dấu '/' thứ hai nên không thoát thư mục được)
        if (path.matches("/[A-Za-z0-9_.-]+\\.(html|css|js)")) {
            try (InputStream res = WebServer.class.getResourceAsStream("/web" + path)) {
                if (res != null) {
                    body = res.readAllBytes();
                    type = path.endsWith(".css") ? "text/css; charset=utf-8"
                         : path.endsWith(".js") ? "text/javascript; charset=utf-8"
                         : "text/html; charset=utf-8";
                }
            }
        }
        String status = "200 OK";
        if (body == null) {
            body = "404 Not Found".getBytes(StandardCharsets.UTF_8);
            status = "404 Not Found";
            type = "text/plain; charset=utf-8";
        }
        out.write(("HTTP/1.1 " + status + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.length
                + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
    }

    // ---------- WebSocket (RFC 6455, tối giản) ----------

    private static void websocket(Socket ws, InputStream in, OutputStream out, String key, int chatPort)
            throws IOException {
        String accept;
        try {
            accept = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1")
                    .digest((key + WS_GUID).getBytes(StandardCharsets.ISO_8859_1)));
        } catch (Exception e) {
            throw new IOException(e);
        }
        // Chỉ nâng cấp HTTP lên WebSocket sau khi kết nối TCP thành công.
        // Nếu TCP Server chưa sẵn sàng, phản hồi 503 để dễ chẩn đoán.
        Socket chat;
        try {
            chat = new Socket("127.0.0.1", chatPort);
        } catch (IOException e) {
            Server.log("WebSocket không kết nối được tới TCP chat port " + chatPort + ": " + e.getMessage());
            httpError(out, "503 Service Unavailable");
            return;
        }
        out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));
        out.flush();
        PrintWriter toChat = new PrintWriter(new OutputStreamWriter(chat.getOutputStream(), StandardCharsets.UTF_8), true);

        // chat server -> trình duyệt
        Thread pump = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(chat.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sendFrame(out, 0x1, line.getBytes(StandardCharsets.UTF_8));
            } catch (IOException ignored) {
            } finally {
                try { sendFrame(out, 0x8, new byte[0]); } catch (IOException ignored) { }
                try { ws.close(); } catch (IOException ignored) { }
            }
        }, "ws-pump");
        pump.setDaemon(true);
        pump.start();

        // Reassemble fragmented WebSocket text messages (RFC 6455 continuation opcode 0x0).
        // Without reassembly, Base64 fragments were interpreted as separate chat commands.
        try {
            ByteArrayOutputStream fragmented = null;
            while (true) {
                int b0 = in.read();
                if (b0 < 0) break;
                if ((b0 & 0x70) != 0) break; // unsupported RSV flags
                boolean fin = (b0 & 0x80) != 0;
                int opcode = b0 & 0x0F;
                int b1 = in.read();
                if (b1 < 0 || (b1 & 0x80) == 0) break; // clients MUST mask frames
                long len = b1 & 0x7F;
                if (len == 126) {
                    int hi=in.read(),lo=in.read();
                    if(hi<0||lo<0)break;
                    len=(hi<<8)|lo;
                } else if (len == 127) {
                    len = 0;
                    for (int i = 0; i < 8; i++) {int part=in.read();if(part<0)throw new EOFException();len=(len<<8)|part;}
                }
                if (len > 1_000_000) break; // text commands only; video uses HTTP
                byte[] mask = new byte[4];readFully(in, mask);
                byte[] payload = new byte[(int) len];readFully(in, payload);
                for (int i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
                if (opcode == 0x8) break;
                if (opcode == 0x9) {if(!fin || payload.length>125)break;sendFrame(out, 0xA, payload);continue;}
                if (opcode == 0xA) continue;
                if (opcode == 0x1) {
                    if (fragmented != null) break;
                    if (fin) {
                        toChat.println(new String(payload,StandardCharsets.UTF_8).replace("\r"," ").replace("\n"," "));
                    } else {
                        fragmented=new ByteArrayOutputStream();fragmented.write(payload);
                    }
                } else if(opcode == 0x0 && fragmented!=null) {
                    if(fragmented.size()+payload.length>1_000_000) break;
                    fragmented.write(payload);
                    if(fin){
                        toChat.println(new String(fragmented.toByteArray(),StandardCharsets.UTF_8)
                            .replace("\r"," ").replace("\n"," "));
                        fragmented=null;
                    }
                } else break;
            }
        } catch (IOException ignored) {
        } finally {
            try { chat.close(); } catch (IOException ignored) { }
        }
    }

    private static void readFully(InputStream in, byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int n = in.read(buf, off, buf.length - off);
            if (n < 0) throw new EOFException();
            off += n;
        }
    }

    private static void sendFrame(OutputStream out, int opcode, byte[] payload) throws IOException {
        synchronized (out) {
            out.write(0x80 | opcode);
            if (payload.length < 126) {
                out.write(payload.length);
            } else if (payload.length < 65536) {
                out.write(126);
                out.write(payload.length >> 8);
                out.write(payload.length & 0xFF);
            } else {
                out.write(127);
                for (int i = 7; i >= 0; i--) out.write((int) ((long) payload.length >> (8 * i)) & 0xFF);
            }
            out.write(payload);
            out.flush();
        }
    }
}
