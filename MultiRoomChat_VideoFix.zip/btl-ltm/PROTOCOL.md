# Multi-room Chat Protocol v2

Transport: one UTF-8 line per command over TCP. Web Client connects to `WebServer` using WebSocket; each WebSocket has one TCP bridge to the same Server.

## Before authentication
- `REGISTER <username> <password>` -> `REGISTEROK<TAB>message` or `ERROR<TAB>message`
- `LOGIN <username> <password>` -> `LOGINOK<TAB>username<TAB>sessionToken`, followed by JOINED lobby.
- `QUIT` closes the connection.
- `NICK` is no longer supported. Login requires a registered account.

## After authentication
- `JOIN <room>` -> `JOINED<TAB>room`; room history is streamed as HISTORY/FILEMSG.
- `LEAVE` -> back to lobby.
- `MSG <text>` -> `CHAT<TAB>room<TAB>sender<TAB>text` to all users in the room.
- `PM <username> <text>` -> `PM<TAB>sender<TAB>receiver<TAB>text` for sender and recipient (recipient may be offline; SQLite stores history).
- `PMHIST <username>` -> `PMCLEAR<TAB>username` then `PMHISTORY<TAB>sender<TAB>receiver<TAB>text<TAB>HH:mm` and FILEMSG.
- `ROOMS` -> `ROOMS<TAB>room:count,...`
- `USERS` -> `USERS<TAB>room<TAB>username,...`
- `PEOPLE` -> `PEOPLE<TAB>username:online|offline,...`
- `WATCH` pushes updated ROOMS, USERS, PEOPLE when users join/leave.
- Legacy TCP `FILE <ROOM|PM> <room|username> <base64(filename)> <base64(mime)> <base64(content)>` (max 600 KB)
  -> `FILEMSG<TAB>ROOM|PM<TAB>target<TAB>sender<TAB>uuid<TAB>filename<TAB>HH:mm`.
- `GET /files/<uuid>` HTTP with `Authorization: Bearer <sessionToken>` downloads only authorized files.

Web browser file uploads use `POST /api/upload` with raw binary HTTP body and `Authorization: Bearer <sessionToken>`, `X-Chat-Mode: ROOM|PM`, `X-Chat-Target: <percent-encoded target>`, `X-File-Name: <percent-encoded UTF-8 file name>` and `Content-Length`. Max 50 MiB. Server stores in uploads/ then notifies viewers over FILEMSG WebSocket event. Filenames have limited safe characters. Supported PNG/JPG/JPEG/GIF/WebP/PDF/TXT/ZIP/MP4/WebM/MOV. Videos can be downloaded; MP4/WebM can also be previewed in browser where codecs are available.

Username 2–20 Unicode letters/digits/underscore/hyphen; room 1–20; passwords 8–128 characters (no spaces in Web form). Message length <=4000 chars. Files in room are readable by any authenticated user (public rooms).

Security caveat: demo transport is plain HTTP/TCP for localhost; TLS required before public deployment.
