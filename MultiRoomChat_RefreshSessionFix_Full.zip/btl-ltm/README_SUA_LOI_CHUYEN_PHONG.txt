FIX: Chuyen tu Tin nhan rieng (PM) ve phong dang tham gia

Trieu chung:
- Dang o phong1, nhap vao chat rieng -> chon lai phong1, giao dien van hien PM.
- Server thong bao: Ban dang o phong 'phong1' roi.

Nguyen nhan:
- Khi bam phong, app.js luon gui JOIN.
- Neu room trung phong dang tham gia, RoomManager.java chi tra INFO, khong gui JOINED.
- Giao dien chi chuyen sang ROOM khi nhan JOINED.

Cach sua:
- app.js them ham openRoom(name). Neu da tham gia phong do, chuyen giao dien truc tiep bang chooseRoom(room) va hien lai tin nhan cu.
- Voi phong khac, van gui JOIN va doi JOINED tu Server.
- Dung chung logic cho click phong, /join, + Phong.
- Khong thay doi Java server, SQLite hoac upload.

Cap nhat nhanh:
1. Thay src/main/resources/web/app.js.
2. Clean and Build -> Run Project NetBeans.
3. Tai lai Chrome bang Ctrl+Shift+R.
