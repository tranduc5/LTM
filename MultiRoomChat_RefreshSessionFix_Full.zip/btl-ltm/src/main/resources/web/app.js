const $ = id => document.getElementById(id);
let ws = null, nick = '', room = '', loggedIn = false, token = '', mode = 'ROOM', peer = '', signup = false;
const roomMessages = new Map(), pmMessages = new Map();
// Database-backed unread counters, keyed separately for public rooms and private chats.
const unreadRoom = new Map(), unreadPM = new Map();
let replyingTo = null;
const AUTH_KEY = 'multiroom.auth.v1';
const VIEW_KEY = 'multiroom.view.v1';
let resuming = false, pendingView = null;
function storeAuth(){
  try{sessionStorage.setItem(AUTH_KEY,JSON.stringify({nick,token}));}catch(_ignored){}
}
function clearStoredAuth(){
  try{sessionStorage.removeItem(AUTH_KEY);sessionStorage.removeItem(VIEW_KEY);}catch(_ignored){}
}
function readStored(key){
  try{return JSON.parse(sessionStorage.getItem(key)||'null');}catch(_ignored){return null;}
}
function saveView(){
  if(!loggedIn)return;
  try{sessionStorage.setItem(VIEW_KEY,JSON.stringify({mode,room,peer}));}catch(_ignored){}
}
const baseTitle = document.title;
function currentVisible(){return document.visibilityState !== 'hidden';}
function unreadLabel(n){return n >= 10 ? '9+ tin nhắn mới' : n + ' tin nhắn mới';}
function setUnread(scope,target,count){
  const map = scope==='ROOM' ? unreadRoom : unreadPM;
  map.set(target.toLowerCase(),Math.max(0,Number(count)||0));
  updateUnreadBadges();
}
function updateUnreadBadges(){
  let total=0;
  document.querySelectorAll('#rooms li, #people li').forEach(li=>{
    const isRoom=Boolean(li.dataset.room);
    const map=isRoom ? unreadRoom : unreadPM;
    const target=(isRoom ? li.dataset.room : li.dataset.person)||'';
    const count=map.get(target.toLowerCase())||0;
    const badge=li.querySelector('.unread-badge');
    if(badge){badge.textContent=count?unreadLabel(count):'';badge.hidden=!count;}
    li.classList.toggle('has-unread',count>0);
  });
  for(const n of unreadRoom.values())total+=n;
  for(const n of unreadPM.values())total+=n;
  document.title=total ? '('+(total>9?'9+':total)+') '+baseTitle : baseTitle;
}
function conversationLabel(text){
  const wrap=document.createElement('span');wrap.className='conversation-label';
  const title=document.createElement('span');title.className='conversation-name';title.textContent=text;
  const badge=document.createElement('span');badge.className='unread-badge';badge.hidden=true;
  wrap.append(title,badge);return wrap;
}
function markSeenActive(){
  if(!loggedIn || !currentVisible())return;
  const target=mode==='ROOM'?room:peer;
  if(!target)return;
  setUnread(mode,target,0);
  send('READ '+mode+' '+target);
}
function cancelReply(){
  replyingTo=null;
  $('replyBar').hidden=true;
  $('replyText').textContent='';
}
function startReply(item,conversation){
  if(!item.id || conversation!==key())return;
  replyingTo={id:item.id,conversation};
  $('replyText').textContent=item.who+': '+(item.text.length>125?item.text.slice(0,125)+'…':item.text);
  $('replyBar').hidden=false;
  $('msg').focus();
}
function syncReply(){if(replyingTo&&replyingTo.conversation!==key())cancelReply();}

const HELP = 'Lệnh: /join <phòng> · /leave · /rooms · /users · /pm <tên> <nội dung> · /quit';
function send(line) { if (ws && ws.readyState === WebSocket.OPEN) ws.send(line); }
function hhmm() { return new Date().toTimeString().slice(0, 5); }
function safe(s) { return String(s || '').replace(/[\t\r\n]/g, ' '); }
function b64(s) { const bytes = new TextEncoder().encode(s); let bin=''; for(const b of bytes) bin+=String.fromCharCode(b);return btoa(bin); }
function where() { return mode === 'ROOM' ? room : peer.toLowerCase(); }
function key() { return mode === 'ROOM' ? 'room:'+room : 'pm:'+peer.toLowerCase(); }
function addElement(item,conversation) {
  const {kind,who,text,time}=item,extra=item.extra||{};
  const d=document.createElement('div');d.className=kind==='sys'?'sys':kind==='err'?'err':'msg'+(who.toLowerCase()===nick.toLowerCase()?' me':'');
  if(kind==='sys'||kind==='err'){d.textContent=text;return d;}
  const w=document.createElement('span');w.className='who';w.textContent=who;
  const t=document.createElement('span');t.className='time';t.textContent=time||hhmm();w.appendChild(t);d.appendChild(w);
  if(item.replyId){
    const quote=document.createElement('div');quote.className='quoted-message';
    const label=document.createElement('strong');label.textContent='↪ '+(item.replySender||'Tin nhắn')+': ';
    const preview=document.createElement('span');preview.textContent=item.replyText||'Tin nhắn gốc';
    quote.append(label,preview);d.appendChild(quote);
  }
  if(extra.fileId){
    const a=document.createElement('a');a.href='#';a.className='download';a.textContent='📎 '+text+' (Tải về)';
    a.onclick=async e=>{e.preventDefault();await download(extra.fileId,text,a);};d.appendChild(a);
    if(/\.(png|jpe?g|gif|webp)$/i.test(text)){
      const img=document.createElement('img');img.className='attachment-image';img.alt=text;img.loading='lazy';d.appendChild(img);
      fetch('/files/'+extra.fileId,{headers:{Authorization:'Bearer '+token}}).then(r=>{if(!r.ok)throw Error('Không có quyền');return r.blob();}).then(blob=>{const url=URL.createObjectURL(blob);img.src=url;img.onload=()=>URL.revokeObjectURL(url);}).catch(()=>img.remove());
    } else if(/\.(mp4|webm|mov)$/i.test(text)) {
      const preview=document.createElement('button');preview.type='button';preview.className='video-preview';
      preview.textContent='▶ Xem video';d.appendChild(preview);
      preview.onclick=async()=>{
        preview.disabled=true;preview.textContent='Đang tải video...';
        try {
          const r=await fetch('/files/'+extra.fileId,{headers:{Authorization:'Bearer '+token}});
          if(!r.ok)throw new Error('Không có quyền xem video');
          const blob=await r.blob(),url=URL.createObjectURL(blob);
          const v=document.createElement('video');v.className='attachment-video';v.controls=true;v.preload='metadata';v.src=url;
          v.onended=()=>URL.revokeObjectURL(url);
          d.replaceChild(v,preview);
        }catch(err){preview.disabled=false;preview.textContent='Không tải được video: '+err.message;}
      };
    }
  }else{const span=document.createElement('span');span.textContent=text;d.appendChild(span);}
  if(item.id){
    const actions=document.createElement('div');actions.className='message-actions';
    const reply=document.createElement('button');reply.type='button';reply.className='reply-action';
    reply.textContent='↩ Trả lời';reply.title='Trả lời tin nhắn này';
    reply.onclick=()=>startReply(item,conversation);
    actions.appendChild(reply);d.appendChild(actions);
  }
  return d;
}
async function download(id,name,link){try{const r=await fetch('/files/'+id,{headers:{Authorization:'Bearer '+token}});if(!r.ok)throw Error('Tải file thất bại');const blob=await r.blob(),url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}catch(e){link.textContent=e.message;}}
function renderLog() {
  const log=$('log');log.replaceChildren();const conversation=key();
  for(const item of (mode==='ROOM'?roomMessages.get(room)||[]:pmMessages.get(peer.toLowerCase())||[]))
    log.appendChild(addElement(item,conversation));
  log.scrollTop=log.scrollHeight;
}
function add(target,item) { const m=target.startsWith('room:')?roomMessages:pmMessages,k=target.slice(target.indexOf(':')+1);if(!m.has(k))m.set(k,[]);m.get(k).push(item);if(m.get(k).length>200)m.get(k).shift();if(target===key())renderLog(); }
function note(text,error=false){if(!loggedIn)return;add(key(),{kind:error?'err':'sys',who:'',text,time:''});}
function chooseRoom(name){mode='ROOM';room=name;peer='';$('roomTitle').textContent='# '+name;$('roomSubtitle').textContent='Phòng công khai';syncReply();markActive();renderLog();markSeenActive();saveView();}
// Dang xem PM nhung van o phong tren Server: chuyen UI ngay, khong JOIN lai phong dang tham gia.
function openRoom(name){
  if(room && room.toLowerCase()===name.toLowerCase()){
    chooseRoom(room);
    $('msg').focus();
  } else {
    send('JOIN '+name);
  }
}
function choosePM(name){if(name.toLowerCase()===nick.toLowerCase())return;mode='PM';peer=name;$('roomTitle').textContent='💬 '+name;$('roomSubtitle').textContent='Tin nhắn riêng';syncReply();markActive();pmMessages.set(name.toLowerCase(),[]);send('PMHIST '+name);renderLog();markSeenActive();saveView();$('msg').focus();}
function meta(f,start){
  const id=Number(f[start]||0),replyId=Number(f[start+1]||0);
  return {id:Number.isSafeInteger(id)&&id>0?id:0,
    replyId:Number.isSafeInteger(replyId)&&replyId>0?replyId:0,
    replySender:f[start+2]||'',replyText:f[start+3]||''};
}
function incoming(target,item){
  add(target,item);
  // The server also pushes persisted unread counters to other, inactive conversations.
  if(target===key() && currentVisible())markSeenActive();
}
document.addEventListener('visibilitychange',()=>{
  if(currentVisible() && loggedIn)markSeenActive();
});
$('cancelReply').onclick=cancelReply;
function connect(name,password,resumeToken=''){
  const previous=ws;
  const path=(location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws';
  $('loginErr').textContent=resumeToken?'Đang khôi phục phiên đăng nhập...':'';
  const socket=new WebSocket(path);
  ws=socket;
  resuming=Boolean(resumeToken);
  // Closing the old socket must not interfere with the new login/reconnect.
  if(previous && previous.readyState<=1) previous.close();
  const command=resumeToken ? 'RESUME '+resumeToken : (signup?'REGISTER ':'LOGIN ')+name+' '+password;
  socket.onopen=()=>{if(ws===socket)socket.send(command);};
  socket.onmessage=e=>{if(ws===socket)handle(e.data);};
  socket.onerror=()=>{
    if(ws===socket && !loggedIn) $('loginErr').textContent='Không mở được WebSocket. Kiểm tra cửa sổ Run của NetBeans và cổng TCP 5000.';
  };
  socket.onclose=()=>{
    if(ws!==socket)return;
    ws=null;
    if(loggedIn){
      $('msg').disabled=true;
      note('Mất kết nối tới Server. Nhấn F5 để kết nối lại nếu phiên còn hợp lệ.',true);
    }else $('loginErr').textContent||='Kết nối WebSocket đã đóng. Kiểm tra Server và cổng TCP 5000.';
  };
}
function handle(line){const f=line.split('\t');switch(f[0]){
case 'REGISTEROK':{signup=false;tabs();$('loginErr').textContent='Đăng ký thành công! Hãy chọn Đăng nhập với tài khoản vừa tạo.';const registered=ws;ws=null;if(registered)registered.close();break;}
case 'LOGINOK':{
  const wasResuming=resuming;resuming=false;
  pendingView=wasResuming?readStored(VIEW_KEY):null;
  nick=f[1];token=f[2];loggedIn=true;storeAuth();
  $('login').style.display='none';$('app').style.display='grid';
  $('myName').textContent=nick;$('me').textContent='Bạn: '+nick;
  $('msg').disabled=false;
  send('WATCH');send('PEOPLE');$('msg').focus();break;
}
case 'NICKOK':break;
case 'ERROR':if(!loggedIn){
  $('loginErr').textContent=f[1]||'Lỗi đăng nhập';
  if(resuming){clearStoredAuth();resuming=false;pendingView=null;}
}else note(f[1]||'Lỗi',true);break;
case 'INFO':if(loggedIn)note(f[1]);break;
case 'JOINED':{
  room=f[1];roomMessages.set(room,[]);chooseRoom(room);
  if(pendingView){
    const view=pendingView;
    if(view.room && view.room.toLowerCase()!==room.toLowerCase()){
      // Restore the previously joined room before restoring a private chat.
      send('JOIN '+view.room);
    }else{
      pendingView=null;
      if(view.mode==='PM' && view.peer) choosePM(view.peer);
    }
  }
  break;
}
case 'SYSTEM':if(f[1]===room&&mode==='ROOM')note(f[2]);break;
case 'CHAT':incoming('room:'+f[1],{kind:'msg',who:f[2],text:f[3],time:hhmm(),...meta(f,4)});break;
case 'HISTORY':add('room:'+f[1],{kind:'msg',who:f[3],text:f[4],time:f[2],...meta(f,5)});break;
case 'PM':{const other=f[1].toLowerCase()===nick.toLowerCase()?f[2]:f[1];incoming('pm:'+other.toLowerCase(),{kind:'msg',who:f[1],text:f[3],time:hhmm(),...meta(f,4)});send('PEOPLE');break;}
case 'PMCLEAR':pmMessages.set(f[1].toLowerCase(),[]);if(key()==='pm:'+f[1].toLowerCase())renderLog();break;
case 'PMHISTORY':{const other=f[1].toLowerCase()===nick.toLowerCase()?f[2]:f[1];add('pm:'+other.toLowerCase(),{kind:'msg',who:f[1],text:f[3],time:f[4],...meta(f,5)});break;}
case 'FILEMSG':{const isRoom=f[1]==='ROOM',target=isRoom?'room:'+f[2]:'pm:'+(f[3].toLowerCase()===nick.toLowerCase()?f[2]:f[3]).toLowerCase();incoming(target,{kind:'msg',who:f[3],text:f[5],time:f[6],extra:{fileId:f[4]},...meta(f,7)});break;}
case 'UNREAD':{const scope=f[1],target=(f[2]||'').toLowerCase(),count=Number(f[3]||0);if(scope==='ROOM'||scope==='PM'){setUnread(scope,target,count);if(key()===(scope==='ROOM'?'room:':'pm:')+target&&currentVisible()&&count>0)markSeenActive();}break;}
case 'ROOMS':renderRooms(f[1]||'');break;
case 'USERS':if(f[1]===room)renderUsers(f[2]||'');break;
case 'PEOPLE':renderPeople(f[1]||'');break;
}}
function renderRooms(s){const ul=$('rooms');ul.replaceChildren();s.split(',').filter(Boolean).forEach(r=>{const i=r.lastIndexOf(':'),name=r.slice(0,i),n=r.slice(i+1),li=document.createElement('li');li.dataset.room=name;li.appendChild(conversationLabel('# '+name));const c=document.createElement('span');c.className='count';c.textContent=n;li.appendChild(c);li.onclick=()=>openRoom(name);ul.appendChild(li);});markActive();updateUnreadBadges();}
function markActive(){document.querySelectorAll('#rooms li').forEach(li=>li.classList.toggle('active',mode==='ROOM'&&li.dataset.room===room));document.querySelectorAll('#people li').forEach(li=>li.classList.toggle('active',mode==='PM'&&li.dataset.person===peer.toLowerCase()));}
function renderUsers(s){const ul=$('users');ul.replaceChildren();s.split(',').filter(Boolean).forEach(u=>{const li=document.createElement('li');li.textContent=u.toLowerCase()===nick.toLowerCase()?u+' (bạn)':u;if(u.toLowerCase()!==nick.toLowerCase())li.onclick=()=>choosePM(u);else li.className='self';ul.appendChild(li);});}
function renderPeople(s){const ul=$('people');ul.replaceChildren();s.split(',').filter(Boolean).forEach(v=>{const i=v.lastIndexOf(':'),person=v.slice(0,i),status=v.slice(i+1);if(person.toLowerCase()===nick.toLowerCase())return;const li=document.createElement('li');li.dataset.person=person.toLowerCase();const label=conversationLabel(person),dot=document.createElement('span');dot.className='dot '+(status==='online'?'online':'offline');const nameSpan=label.querySelector('.conversation-name');nameSpan.prepend(dot,document.createTextNode(' '));li.append(label);li.onclick=()=>choosePM(person);ul.appendChild(li);});markActive();updateUnreadBadges();}
function tabs(){$('loginTab').classList.toggle('selected',!signup);$('registerTab').classList.toggle('selected',signup);$('loginSubmit').textContent=signup?'Tạo tài khoản':'Đăng nhập';$('loginErr').textContent='';$('password').autocomplete=signup?'new-password':'current-password';}
$('loginTab').onclick=()=>{signup=false;tabs();};$('registerTab').onclick=()=>{signup=true;tabs();};
$('loginForm').onsubmit=e=>{e.preventDefault();let n=$('nick').value.trim(),password=$('password').value;if(!/^[\p{L}\p{N}_-]{2,20}$/u.test(n)||password.length<8||password.includes(' ')){ $('loginErr').textContent='Tên 2–20 ký tự; mật khẩu >= 8 ký tự, không chứa dấu cách.';return;}connect(n,password);};
$('sendForm').onsubmit=e=>{e.preventDefault();const text=$('msg').value.trim();if(!text)return;$('msg').value='';if(text==='/help'){note(HELP);return;}if(text.startsWith('/')){const p=text.slice(1).split(/\s+/),cmd=p[0].toLowerCase();if(cmd==='join'&&p[1])openRoom(p[1]);else if(cmd==='leave')send('LEAVE');else if(cmd==='rooms')send('ROOMS');else if(cmd==='users')send('USERS');else if(cmd==='pm'&&p.length>=3){choosePM(p[1]);send('PM '+p[1]+' '+p.slice(2).join(' '));}else if(cmd==='quit')logout();else note(HELP,true);}else {if(replyingTo&&replyingTo.conversation===key()){send(mode==='ROOM'?'REPLYROOM '+replyingTo.id+' '+safe(text):'REPLYPM '+peer+' '+replyingTo.id+' '+safe(text));cancelReply();}else send(mode==='ROOM'?'MSG '+safe(text):'PM '+peer+' '+safe(text));}};
$('newRoom').onclick=()=>{const r=prompt('Tên phòng (chữ, số, _ hoặc -):');if(r&&/^[\p{L}\p{N}_-]{1,20}$/u.test(r.trim()))openRoom(r.trim());};
function logout(){
  clearStoredAuth();
  const old=ws;ws=null;
  if(old&&old.readyState===WebSocket.OPEN)old.send('LOGOUT');
  if(old)old.close();
  loggedIn=false;resuming=false;pendingView=null;
  token='';nick='';room='';peer='';mode='ROOM';cancelReply();
  roomMessages.clear();pmMessages.clear();unreadRoom.clear();unreadPM.clear();updateUnreadBadges();
  $('app').style.display='none';$('login').style.display='';
  $('password').value='';$('loginErr').textContent='Bạn đã đăng xuất.';
}
$('logout').onclick=logout;
$('file').onchange=async()=>{
  const file=$('file').files[0];$('file').value='';if(!file)return;
  const max=50*1024*1024;
  if(file.size===0||file.size>max){note('File phải từ 1 byte đến 50 MB',true);return;}
  if(!/\.(png|jpe?g|gif|webp|pdf|txt|zip|mp4|webm|mov)$/i.test(file.name)){
    note('Chỉ hỗ trợ ảnh, PDF, TXT, ZIP, MP4, WebM và MOV',true);return;
  }
  if(!loggedIn||!token){note('Bạn cần đăng nhập lại trước khi gửi file',true);return;}
  const currentMode=mode,currentTarget=mode==='ROOM'?room:peer;
  if(!currentTarget){note('Chưa chọn phòng hoặc người nhận.',true);return;}
  const uploadKey=currentMode==='ROOM'?'room:'+currentTarget:'pm:'+currentTarget.toLowerCase();
  const input=$('file');input.disabled=true;
  // Thông báo đang tải là tạm thời; không được lưu thành tin nhắn vĩnh viễn.
  const pending={kind:'sys',who:'',text:'Đang tải lên '+file.name+' ('+(file.size/1024/1024).toFixed(2)+' MB)...',time:''};
  add(uploadKey,pending);
  try{
    const response=await fetch('/api/upload',{
      method:'POST',
      headers:{Authorization:'Bearer '+token,
        'Content-Type':'application/octet-stream',
        'X-Chat-Mode':currentMode,
        'X-Chat-Target':encodeURIComponent(currentTarget),
        'X-File-Name':encodeURIComponent(file.name)},
      body:file
    });
    const result=await response.text();
    if(!response.ok)throw Error(result||'Upload thất bại (HTTP '+response.status+')');
    // Tin nhắn tệp thực tế được hiển thị bằng sự kiện FILEMSG từ Server.
  }catch(err){
    add(uploadKey,{kind:'err',who:'',text:'Không gửi được '+file.name+': '+err.message,time:''});
  }finally{
    // Xóa đúng thông báo của lần gửi này, kể cả khi người dùng đã đổi phòng/PM.
    const store=uploadKey.startsWith('room:')?roomMessages:pmMessages;
    const messages=store.get(uploadKey.slice(uploadKey.indexOf(':')+1));
    if(messages){const i=messages.indexOf(pending);if(i!==-1)messages.splice(i,1);}
    if(key()===uploadKey)renderLog();
    input.disabled=false;
  }
};

// Restore a still-valid session automatically after F5; never persist passwords.
(function restoreAfterRefresh(){
  const saved=readStored(AUTH_KEY);
  if(saved && typeof saved.nick==='string' && typeof saved.token==='string' && saved.token.length>=32){
    $('nick').value=saved.nick;
    connect('', '', saved.token);
  }else if(saved){clearStoredAuth();}
})();
