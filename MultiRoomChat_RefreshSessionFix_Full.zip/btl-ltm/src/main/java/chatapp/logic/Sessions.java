package chatapp.logic;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Short-lived bearer sessions for reconnect after browser refresh (F5).
 * Tokens live in server RAM; a server restart invalidates them.
 * Sign-out revokes tokens; a temporary WebSocket disconnect does not.
 */
public final class Sessions {
    private static final long TTL_MILLIS = 12L * 60 * 60 * 1000;
    private static final Map<String, Entry> TOKENS = new ConcurrentHashMap<>();
    private static final SecureRandom RNG = new SecureRandom();

    private static final class Entry {
        final String user;
        final long expiresAt;
        Entry(String user, long expiresAt) {this.user=user; this.expiresAt=expiresAt;}
    }

    public static String create(String user) {
        byte[] bytes=new byte[32]; RNG.nextBytes(bytes);
        String token=Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        TOKENS.put(token, new Entry(user, System.currentTimeMillis() + TTL_MILLIS));
        return token;
    }

    public static String user(String token) {
        if (token==null || token.isEmpty()) return null;
        Entry entry=TOKENS.get(token);
        if(entry==null)return null;
        if(System.currentTimeMillis() >= entry.expiresAt){TOKENS.remove(token,entry);return null;}
        return entry.user;
    }

    public static void revoke(String token) {
        if(token!=null)TOKENS.remove(token);
    }
    private Sessions(){}
}
