package chatapp.logic;

import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.security.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** SQLite persistence for accounts, rooms, chat messages and attachments. */
public final class ChatDatabase {
    private final String url;
    public ChatDatabase() {
        try { Files.createDirectories(Path.of("data")); } catch (Exception e) { throw new IllegalStateException(e); }
        url = "jdbc:sqlite:" + Path.of("data", "chat.db").toAbsolutePath();
        try (Connection c = open(); Statement s = c.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY COLLATE NOCASE, salt TEXT NOT NULL, hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS rooms (name TEXT PRIMARY KEY COLLATE NOCASE, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT NOT NULL, room TEXT, receiver TEXT, body TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'TEXT', created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
            boolean existingReads=false;
            try(ResultSet check=s.executeQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name='message_reads'")) {
                existingReads=check.next();
            }
            s.executeUpdate("CREATE TABLE IF NOT EXISTS message_reads (username TEXT NOT NULL COLLATE NOCASE, scope TEXT NOT NULL, target TEXT NOT NULL COLLATE NOCASE, last_id INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(username,scope,target))");
            if(!existingReads) {
                // First-time migration: old public messages should not be marked unread for everyone.
                s.executeUpdate("INSERT OR IGNORE INTO message_reads(username,scope,target,last_id) " +
                    "SELECT u.username,'ROOM',r.name,COALESCE((SELECT MAX(id) FROM messages m WHERE m.room=r.name COLLATE NOCASE),0) " +
                    "FROM users u CROSS JOIN rooms r");
            }
            ensureReplyColumn(c);
            s.executeUpdate("CREATE TABLE IF NOT EXISTS attachments (id TEXT PRIMARY KEY, message_id INTEGER NOT NULL, original_name TEXT NOT NULL, media_type TEXT NOT NULL, stored_name TEXT NOT NULL, size INTEGER NOT NULL, FOREIGN KEY(message_id) REFERENCES messages(id))");
            s.executeUpdate("CREATE INDEX IF NOT EXISTS idx_room_history ON messages(room,id)");
            s.executeUpdate("CREATE INDEX IF NOT EXISTS idx_pm_history ON messages(sender,receiver,id)");
            s.executeUpdate("INSERT OR IGNORE INTO rooms(name) VALUES('lobby')");
        } catch (SQLException e) { throw new IllegalStateException("Không mở được SQLite (kiểm tra sqlite-jdbc dependency)", e); }
    }
    // In-place migration for existing data/chat.db; keep old accounts, rooms and messages.
    private static void ensureReplyColumn(Connection c) throws SQLException {
        boolean found = false;
        try (Statement s=c.createStatement(); ResultSet r=s.executeQuery("PRAGMA table_info(messages)")) {
            while (r.next()) if ("reply_to_id".equalsIgnoreCase(r.getString("name"))) found=true;
        }
        if (!found) try (Statement s=c.createStatement()) {
            s.executeUpdate("ALTER TABLE messages ADD COLUMN reply_to_id INTEGER");
        }
    }

    private Connection open() throws SQLException {
        Connection c = DriverManager.getConnection(url);
        try (Statement s = c.createStatement()) { s.execute("PRAGMA busy_timeout=5000"); s.execute("PRAGMA foreign_keys=ON"); }
        return c;
    }
    public synchronized boolean signup(String user, String password) {
        if (!user.matches("[\\p{L}\\p{N}_-]{2,20}") || password.length()<8 || password.length()>128) return false;
        byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
        try (Connection c = open(); PreparedStatement p = c.prepareStatement("INSERT INTO users(username,salt,hash) VALUES(?,?,?)")) {
            p.setString(1,user); p.setString(2,Base64.getEncoder().encodeToString(salt)); p.setString(3,derive(password,salt)); p.executeUpdate();
            // Old public room history predating the account is not considered unread.
            try(PreparedStatement init=c.prepareStatement(
                "INSERT OR IGNORE INTO message_reads(username,scope,target,last_id) " +
                "SELECT ?, 'ROOM', r.name, COALESCE((SELECT MAX(id) FROM messages m WHERE m.room=r.name COLLATE NOCASE),0) FROM rooms r")) {
                init.setString(1,user.toLowerCase(Locale.ROOT)); init.executeUpdate();
            }
            return true;
        } catch (SQLException e) { return false; }
    }
    public synchronized boolean login(String user,String password) {
        try(Connection c=open();PreparedStatement p=c.prepareStatement("SELECT salt,hash FROM users WHERE username=?")) {
            p.setString(1,user);
            try(ResultSet r=p.executeQuery()) { if (!r.next()) return false;
                byte[] salt=Base64.getDecoder().decode(r.getString(1));
                return MessageDigest.isEqual(derive(password,salt).getBytes(java.nio.charset.StandardCharsets.UTF_8),r.getString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
        } catch(Exception e) { return false; }
    }
    private static String derive(String password,byte[] salt) {
        char[] chars=password.toCharArray(); PBEKeySpec spec=new PBEKeySpec(chars,salt,210000,256);
        try { return Base64.getEncoder().encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded()); }
        catch(Exception e){throw new IllegalStateException(e);} finally { spec.clearPassword(); Arrays.fill(chars,'\0'); }
    }
    public synchronized boolean exists(String name) {
        try(Connection c=open(); PreparedStatement p=c.prepareStatement("SELECT 1 FROM users WHERE username=?")) {
            p.setString(1,name);try(ResultSet r=p.executeQuery()){return r.next();}
        }catch(SQLException e){throw new IllegalStateException(e);}
    }
    public synchronized List<String> users() {
        List<String> values=new ArrayList<>();
        try(Connection c=open(); Statement s=c.createStatement(); ResultSet r=s.executeQuery("SELECT username FROM users ORDER BY username")) {
            while(r.next()) values.add(r.getString(1));
        }catch(SQLException e){throw new IllegalStateException(e);}return values;
    }
    public synchronized List<String> rooms() {
        List<String> values=new ArrayList<>();
        try(Connection c=open();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT name FROM rooms ORDER BY name")) {
            while(r.next())values.add(r.getString(1));
        }catch(SQLException e){throw new IllegalStateException(e);}return values;
    }
    public synchronized void addRoom(String room){
        try(Connection c=open();PreparedStatement p=c.prepareStatement("INSERT OR IGNORE INTO rooms(name) VALUES(?)")) {p.setString(1,room);p.executeUpdate();}
        catch(SQLException e){throw new IllegalStateException(e);}
    }
    public synchronized long addMessage(String sender,String room,String receiver,String body,String kind) {
        return addMessage(sender,room,receiver,body,kind,0);
    }
    public synchronized long addMessage(String sender,String room,String receiver,String body,String kind,long replyTo) {
        try(Connection c=open();PreparedStatement p=c.prepareStatement(
            "INSERT INTO messages(sender,room,receiver,body,kind,created_at,reply_to_id) VALUES(?,?,?,?,?,?,?)",
            Statement.RETURN_GENERATED_KEYS)) {
            p.setString(1,sender);p.setString(2,room);p.setString(3,receiver);p.setString(4,body);p.setString(5,kind);
            p.setString(6,java.time.LocalDateTime.now().toString());
            if(replyTo>0)p.setLong(7,replyTo); else p.setNull(7,Types.BIGINT);
            p.executeUpdate();
            try(ResultSet r=p.getGeneratedKeys()){return r.next()?r.getLong(1):-1;}
        }catch(SQLException e){throw new IllegalStateException(e);}
    }

    /** Returns sender and 90-character preview only when the original belongs to this conversation. */
    public synchronized String[] replyInRoom(long id,String room) {
        try(Connection c=open();PreparedStatement p=c.prepareStatement(
            "SELECT sender,body FROM messages WHERE id=? AND room=? COLLATE NOCASE")) {
            p.setLong(1,id);p.setString(2,room);
            try(ResultSet r=p.executeQuery()) {return r.next()?new String[]{r.getString(1),preview(r.getString(2))}:null;}
        }catch(SQLException e){throw new IllegalStateException(e);}
    }
    public synchronized String[] replyInPM(long id,String a,String b) {
        try(Connection c=open();PreparedStatement p=c.prepareStatement(
            "SELECT sender,body FROM messages WHERE id=? AND room IS NULL AND " +
            "((sender=? COLLATE NOCASE AND receiver=? COLLATE NOCASE) OR " +
            "(sender=? COLLATE NOCASE AND receiver=? COLLATE NOCASE))")) {
            p.setLong(1,id);p.setString(2,a);p.setString(3,b);p.setString(4,b);p.setString(5,a);
            try(ResultSet r=p.executeQuery()) {return r.next()?new String[]{r.getString(1),preview(r.getString(2))}:null;}
        }catch(SQLException e){throw new IllegalStateException(e);}
    }
    public static String preview(String s) {
        if(s==null)return "";
        String clean=s.replace('\t',' ').replace('\r',' ').replace('\n',' ');
        return clean.length()>90?clean.substring(0,90)+"…":clean;
    }

    // Read cursor is persistent: reopening the browser keeps unread counts consistent.
    public synchronized void markRead(String user,String scope,String target) {
        if(!"ROOM".equals(scope)&&!"PM".equals(scope))return;
        String sql="ROOM".equals(scope)?
            "SELECT COALESCE(MAX(id),0) FROM messages WHERE room=? COLLATE NOCASE":
            "SELECT COALESCE(MAX(id),0) FROM messages WHERE sender=? COLLATE NOCASE AND receiver=? COLLATE NOCASE";
        try(Connection c=open();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,target);if("PM".equals(scope))p.setString(2,user);
            long latest;
            try(ResultSet r=p.executeQuery()){latest=r.next()?r.getLong(1):0;}
            try(PreparedStatement update=c.prepareStatement(
                "INSERT INTO message_reads(username,scope,target,last_id) VALUES(?,?,?,?) " +
                "ON CONFLICT(username,scope,target) DO UPDATE SET last_id=MAX(last_id,excluded.last_id)")) {
                update.setString(1,user.toLowerCase(Locale.ROOT)); update.setString(2,scope);
                update.setString(3,target.toLowerCase(Locale.ROOT)); update.setLong(4,latest);
                update.executeUpdate();
            }
        }catch(SQLException e){throw new IllegalStateException(e);}
    }
    public synchronized int unreadRoom(String user,String room) {
        String sql="SELECT COUNT(*) FROM messages WHERE room=? COLLATE NOCASE " +
            "AND sender<>? COLLATE NOCASE AND id>COALESCE((SELECT last_id FROM message_reads " +
            "WHERE username=? COLLATE NOCASE AND scope='ROOM' AND target=? COLLATE NOCASE),0)";
        try(Connection c=open();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,room);p.setString(2,user);p.setString(3,user);p.setString(4,room);
            try(ResultSet r=p.executeQuery()){return r.next()?r.getInt(1):0;}
        }catch(SQLException e){throw new IllegalStateException(e);}
    }
    public synchronized int unreadPM(String user,String peer) {
        String sql="SELECT COUNT(*) FROM messages WHERE sender=? COLLATE NOCASE AND receiver=? COLLATE NOCASE " +
            "AND id>COALESCE((SELECT last_id FROM message_reads WHERE username=? COLLATE NOCASE " +
            "AND scope='PM' AND target=? COLLATE NOCASE),0)";
        try(Connection c=open();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,peer);p.setString(2,user);p.setString(3,user);p.setString(4,peer);
            try(ResultSet r=p.executeQuery()){return r.next()?r.getInt(1):0;}
        }catch(SQLException e){throw new IllegalStateException(e);}
    }
    // Each record: kind, time, sender, recipient-or-room, body, attachment id, id, reply_id, reply sender, reply preview
    public synchronized List<String[]> roomHistory(String room) {
        List<String[]> result=new ArrayList<>();
        String sql="SELECT m.kind,substr(m.created_at,12,5),m.sender,m.room,m.body,COALESCE(a.id,'')," +
            "m.id,COALESCE(m.reply_to_id,0),COALESCE(original.sender,''),COALESCE(original.body,'') " +
            "FROM messages m LEFT JOIN attachments a ON a.message_id=m.id " +
            "LEFT JOIN messages original ON original.id=m.reply_to_id " +
            "WHERE m.room=? ORDER BY m.id DESC LIMIT 100";
        try(Connection c=open();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,room);try(ResultSet r=p.executeQuery()){while(r.next())result.add(record(r));}
        }catch(SQLException e){throw new IllegalStateException(e);} Collections.reverse(result);return result;
    }
    public synchronized List<String[]> pmHistory(String one,String two) {
        List<String[]> result=new ArrayList<>();
        String sql="SELECT m.kind,substr(m.created_at,12,5),m.sender,m.receiver,m.body,COALESCE(a.id,'')," +
            "m.id,COALESCE(m.reply_to_id,0),COALESCE(original.sender,''),COALESCE(original.body,'') " +
            "FROM messages m LEFT JOIN attachments a ON a.message_id=m.id " +
            "LEFT JOIN messages original ON original.id=m.reply_to_id WHERE " +
            "(m.sender=? COLLATE NOCASE AND m.receiver=? COLLATE NOCASE) OR " +
            "(m.sender=? COLLATE NOCASE AND m.receiver=? COLLATE NOCASE) ORDER BY m.id DESC LIMIT 100";
        try(Connection c=open();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,one);p.setString(2,two);p.setString(3,two);p.setString(4,one);
            try(ResultSet r=p.executeQuery()){while(r.next())result.add(record(r));}
        }catch(SQLException e){throw new IllegalStateException(e);} Collections.reverse(result);return result;
    }
    private static String[] record(ResultSet r)throws SQLException {
        return new String[]{r.getString(1),r.getString(2),r.getString(3),r.getString(4),
            r.getString(5),r.getString(6),r.getString(7),r.getString(8),r.getString(9),preview(r.getString(10))};
    }
    public synchronized void addAttachment(String id,long messageId,String name,String mime,String storedName,long size){
        try(Connection c=open();PreparedStatement p=c.prepareStatement("INSERT INTO attachments(id,message_id,original_name,media_type,stored_name,size) VALUES(?,?,?,?,?,?)")) {
            p.setString(1,id);p.setLong(2,messageId);p.setString(3,name);p.setString(4,mime);p.setString(5,storedName);p.setLong(6,size);p.executeUpdate();
        }catch(SQLException e){throw new IllegalStateException(e);}
    }
    public synchronized String[] attachment(String id,String requester){
        String sql="SELECT a.stored_name,a.media_type,a.original_name FROM attachments a JOIN messages m ON m.id=a.message_id WHERE a.id=? AND (m.room IS NOT NULL OR m.sender=? COLLATE NOCASE OR m.receiver=? COLLATE NOCASE)";
        try(Connection c=open();PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,id);p.setString(2,requester);p.setString(3,requester);
            try(ResultSet r=p.executeQuery()){if(r.next())return new String[]{r.getString(1),r.getString(2),r.getString(3)};}
        }catch(SQLException e){throw new IllegalStateException(e);}return null;
    }
}
