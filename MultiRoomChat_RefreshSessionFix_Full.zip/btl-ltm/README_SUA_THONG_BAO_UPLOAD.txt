SỬA LỖI THÔNG BÁO “ĐANG TẢI LÊN” KHÔNG BIẾN MẤT

Nguồn: MultiRoomChat_VideoFix.zip
Đã sửa: src/main/resources/web/app.js

- Khi chọn tệp, tạo một thông báo tải lên tạm thời trong đúng hội thoại.
- Nếu HTTP /api/upload trả 200, xóa thông báo đang tải; tin nhắn FILEMSG vẫn hiển thị.
- Nếu HTTP trả lỗi hoặc mất mạng, xóa thông báo đang tải và giữ thông báo lỗi.
- Nếu chuyển phòng/PM giữa lúc gửi, vẫn xóa đúng thông báo tại hội thoại ban đầu.
- Không thay đổi WebServer.java, database, giao thức, giới hạn file hay tính năng video.

HƯỚNG DẪN
1. Tắt Server cũ ở NetBeans (tránh trùng cổng).
2. Giải nén ZIP mới; mở project btl-ltm trong NetBeans.
3. Clean and Build -> Run Project.
4. Truy cập localhost:8080, nhấn Ctrl+Shift+R để nạp app.js mới.
5. Kiểm thử gửi ảnh/PDF, và tệp thất bại (ví dụ mất kết nối).
6. Nếu giữ tài khoản/lịch sử, sao chép thư mục data và uploads từ dự án cũ sau khi đã tắt Server.
