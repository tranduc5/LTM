# Unread / Reply protocol extension

The existing protocol is still line-oriented (tab-delimited server events).

Client commands:

```
READ ROOM phong1
READ PM trannhat
REPLYROOM 123 This refers to message 123 in my current room
REPLYPM trannhat 456 This refers to a message in our private conversation
```

Server unread events:

```
UNREAD\tROOM\tphong1\t4
UNREAD\tPM\ttrannhat\t12
```

`CHAT`, `HISTORY`, `PM`, and `PMHISTORY` append `message_id`,
`reply_to_id`, `reply_sender`, and `reply_preview` **after** original
fields. `FILEMSG` appends these after the timestamp. Existing Java CLI and
Swing still use their old positional fields. All text is treated as data in
the browser with `textContent` (not `innerHTML`).

SQLite schema automatically migrates on startup:

- `messages.reply_to_id` (`ALTER TABLE` when missing)
- `message_reads(username,scope,target,last_id)` for persistent read cursors

For public rooms, every other participant's message counts as unread if it
is newer than `last_id`; own messages never count. In PM only *incoming*
messages count. The server validates reply ownership in the target
conversation before inserting a reply.
